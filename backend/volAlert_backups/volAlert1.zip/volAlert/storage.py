from datetime import datetime   

class Storage:
    def __init__(self):
        self.volumes = {}        # token -> live volume
        self.symbols = {}        # token -> symbol
        self.alerts = {}         # symbol -> alerts
        self.historical = {}     # symbol -> historical metrics
        self.logs = []          
        self.prices = {}

    def add_log(self, message):
        self.logs.append({
            "time": datetime.now().strftime("%H:%M:%S"),
            "message": message
        })
        if len(self.logs) > 300:
            self.logs.pop(0)

    def get_logs(self):
        return self.logs
    
    # -------- Stocks --------
    def register_stock(self, token, symbol):
        self.symbols[token] = symbol

    # -------- Live Volume --------
    def update_volume(self, token, volume):
        self.volumes[token] = volume

    # -------- Historical --------
    def set_historical_metrics(self, symbol, metrics):
        self.historical[symbol] = metrics

    # -------- UI Data --------
    def get_all_volumes(self):
        result = []

        for token, live_vol in self.volumes.items():
            symbol = self.symbols.get(token, "")
            hist = self.historical.get(symbol, {})

            result.append({
                "symbol": symbol,
                "live_volume": live_vol,
                "prev_day": hist.get("prev_day"),
                "weekly_avg": hist.get("weekly_avg"),
                "monthly_avg": hist.get("monthly_avg")
            })

        return result
    
    # -------------------------------------------------
    # Alerts
    # -------------------------------------------------
    def add_alert(self, symbol, alert):
        """
        Add a new alert for a symbol
        """
        if symbol not in self.alerts:
            self.alerts[symbol] = []

        self.alerts[symbol].append(alert)

    def get_alerts(self, symbol):
        return self.alerts.get(symbol, [])
