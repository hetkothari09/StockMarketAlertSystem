from alert_engine import AlertEngine
from notifier import Notifier


class MarketDataHandler:
    def __init__(self, storage):
        self.storage = storage
        Notifier.storage = storage
        self.alert_engine = AlertEngine(Notifier)
        self.crossed_weekly = set()

    def handle(self, data):
        token = data["Tkn"]
        volume = data["TTQ"]
        price = data.get("LTP")  # or equivalent
        self.storage.prices[token] = price

        self.storage.update_volume(token, volume)

        symbol = self.storage.symbols.get(token)
        
        if not symbol:
            return
        
        alerts = self.storage.get_alerts(symbol)
        if alerts:
            self.alert_engine.evaluate(symbol, volume, alerts)
