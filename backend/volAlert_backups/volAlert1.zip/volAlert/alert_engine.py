class VolumeAlert:
    def __init__(self, symbol, threshold):
        self.symbol = symbol
        self.threshold = threshold
        self.triggered = False

    def should_trigger(self, current_volume):
        return (not self.triggered) and current_volume >= self.threshold

    def mark_triggered(self):
        self.triggered = True


# can add multiple custom alerts

class AlertEngine:
    def __init__(self, notifier):
        self.notifier = notifier

    def evaluate(self, symbol, current_volume, alerts):
        """
        Check all alerts for a symbol
        """
        for alert in alerts:
            if alert.should_trigger(current_volume):
                self.notifier.notify(
                    symbol=symbol,
                    volume=current_volume,
                    threshold=alert.threshold
                )
                alert.mark_triggered()
