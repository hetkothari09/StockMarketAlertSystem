const crossedOnce = new Set();

async function fetchMarketData() {
    const response = await fetch("/data");
    const data = await response.json();

    const tbody = document.getElementById("market-body");
    tbody.innerHTML = "";

    data.forEach(row => {
        let statusClass = "status-normal";
        let statusText = "NORMAL";

        if (row.weekly_avg && row.live_volume > row.weekly_avg) {
            statusClass = "status-high";
            statusText = "HIGH VOL";

            if (!crossedOnce.has(row.symbol)) {
                addLog(`${row.symbol} crossed weekly avg volume`);
                crossedOnce.add(row.symbol);
            }
        }

        const tr = document.createElement("tr");

        tr.innerHTML = `
            <td>${row.symbol}</td>
            <td>${format(row.live_volume)}</td>
            <td>${format(row.prev_day)}</td>
            <td>${format(row.weekly_avg)}</td>
            <td>${format(row.monthly_avg)}</td>
            <td class="${statusClass}">${statusText}</td>
        `;

        tbody.appendChild(tr);
    });
}


function format(val) {
    if (!val) return "-";
    return val.toLocaleString();
}

/* ===== Logs ===== */
function addLog(message) {
    const logs = document.getElementById("logs");
    const div = document.createElement("div");
    div.className = "log";
    div.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
    logs.prepend(div);
}

// const crossedOnce = new Set();

// if (row.weekly_avg && row.live_volume > row.weekly_avg) {
//     statusClass = "status-high";
//     statusText = "HIGH VOL";

//     if (!crossedOnce.has(row.symbol)) {
//         addLog(`${row.symbol} crossed weekly avg volume`);
//         crossedOnce.add(row.symbol);
//     }
// }
/* ===== Refresh ===== */
setInterval(fetchMarketData, 1000);
