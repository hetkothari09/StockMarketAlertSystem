# historical_volume.py

import json
from collections import defaultdict

class HistoricalVolumeLoader:
    """
    Expects data in the form:
    [
      {"symbol": "INFY", "date": "2025-01-01", "volume": 4800000},
      ...
    ]
    """

    def __init__(self, filepath):
        self.filepath = filepath

    def load(self):
        with open(self.filepath, "r") as f:
            data = json.load(f)

        grouped = defaultdict(list)

        for row in data:
            grouped[row["symbol"]].append(row["volume"])

        metrics = {}

        for symbol, volumes in grouped.items():
            if not volumes:
                continue

            metrics[symbol] = {
                "prev_day": volumes[-1],
                "weekly_avg": sum(volumes[-5:]) // min(5, len(volumes)),
                "monthly_avg": sum(volumes[-20:]) // min(20, len(volumes))
            }

        return metrics
